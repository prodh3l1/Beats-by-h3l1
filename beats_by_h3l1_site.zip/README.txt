
# beats by h3l1

Este é um site simples e minimalista para promover beats, inspirado no layout do RaspoBeats.com.

## Como publicar

Você pode usar:

### GitHub Pages

1. Crie um repositório no GitHub.
2. Faça upload dos arquivos.
3. Vá em "Settings" > "Pages" > selecione a branch e `/root` como diretório.

### Netlify

1. Acesse https://netlify.com
2. Faça login e clique em "Add new site" > "Deploy manually"
3. Faça upload do arquivo `.zip`.

Pronto! Seu site estará no ar.
